package UI;

import data.GestorDatos;
import model.Direccion;
import model.Empleado;
import model.Tour;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        System.out.println("=== PERSONAS Y EMPLEADOS ===");

        Direccion direccion1 = new Direccion("Calle Los Lagos 123", "Llanquihue", "Los Lagos");
        Direccion direccion2 = new Direccion("Av. Costanera 456", "Puerto Varas", "Los Lagos");
        Direccion direccion3 = new Direccion("Camino Frutillar 789", "Frutillar", "Los Lagos");

        Persona cliente = new Persona("María Soto", "12.345.678-9", "912345678", direccion1);
        Empleado guia = new Empleado("Carlos Pérez", "11.222.333-4", "987654321", direccion2, "Guía turístico", 650000);
        Empleado operador = new Empleado("Ana Muñoz", "15.444.555-6", "956789123", direccion3, "Operadora turística", 700000);

        System.out.println(cliente);
        System.out.println(guia);
        System.out.println(operador);

        System.out.println("\n=== TOURS DESDE ARCHIVO ===");

        GestorDatos gestor = new GestorDatos();
        ArrayList<Tour> tours = gestor.leerTours("resources/tours.txt");

        for (Tour tour : tours) {
            System.out.println(tour);
        }

        System.out.println("\n=== TOURS GASTRONÓMICOS ===");

        for (Tour tour : tours) {
            if (tour.getTipo().equalsIgnoreCase("gastronomico")) {
                System.out.println(tour);
            }
        }
    }
}