# LlanquihueTourApp - Semana 6

## Objetivo de esta semana

El objetivo de esta semana es implementar una jerarquía de clases con herencia simple para representar los diferentes servicios turísticos de la agencia Llanquihue Tour.

Se creó una clase base llamada `ServicioTuristico`, que contiene los atributos comunes de todos los servicios, y tres subclases que representan servicios específicos de la agencia.

## Organización del proyecto

El proyecto está organizado en paquetes según su responsabilidad:

- `model`: contiene la jerarquía de clases del sistema.
- `data`: contiene la clase encargada de crear datos de prueba.
- `ui`: contiene la clase principal que ejecuta el programa.

## Clases creadas

### Paquete model

- `ServicioTuristico`: superclase con los atributos `nombre` y `duracionHoras`.
- `RutaGastronomica`: subclase que agrega el atributo `numeroDeParadas`.
- `PaseoLacustre`: subclase que agrega el atributo `tipoEmbarcacion`.
- `ExcursionCultural`: subclase que agrega el atributo `lugarHistorico`.

### Paquete data

- `GestorServicios`: clase que crea dos objetos de prueba por cada tipo de servicio turístico.

### Paquete ui

- `Main`: clase principal que ejecuta el programa y muestra los servicios por consola.

## Conceptos aplicados

- Herencia simple.
- Uso de `super(...)` en constructores.
- Sobrescritura del método `toString()`.
- Organización del proyecto por paquetes.
- Creación de objetos de prueba.

## Instrucciones para ejecutar

1. Abrir el proyecto en IntelliJ IDEA.
2. Ir a la clase `Main`, ubicada en el paquete `ui`.
3. Ejecutar el método `main`.
4. Revisar en consola el listado de servicios turísticos disponibles.

## Resultado esperado en consola

Al ejecutar el programa, se muestran seis servicios turísticos:

- Dos rutas gastronómicas.
- Dos paseos lacustres.
- Dos excursiones culturales.
