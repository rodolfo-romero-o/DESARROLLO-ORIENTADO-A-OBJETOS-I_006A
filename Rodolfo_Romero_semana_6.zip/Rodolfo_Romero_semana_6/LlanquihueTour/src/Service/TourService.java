package service;

import model.Tour;

import java.util.ArrayList;

public class TourService {

    public void mostrarTours(ArrayList<Tour> tours) {

        System.out.println("===== LISTADO DE TOURS =====");

        for (Tour tour : tours) {
            System.out.println(tour);
        }
    }

    public void buscarPorTipo(ArrayList<Tour> tours, String tipo) {

        System.out.println("===== BÚSQUEDA POR TIPO: " + tipo + " =====");

        boolean encontrado = false;

        for (Tour tour : tours) {
            if (tour.getTipo().equalsIgnoreCase(tipo)) {
                System.out.println(tour);
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontraron tours del tipo indicado.");
        }
    }

    public void buscarPorNombre(ArrayList<Tour> tours, String nombre) {

        System.out.println("===== BÚSQUEDA POR NOMBRE: " + nombre + " =====");

        boolean encontrado = false;

        for (Tour tour : tours) {
            if (tour.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                System.out.println(tour);
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontraron tours con ese nombre.");
        }
    }
}