package app;

import data.GestorDatos;
import model.OperadorTuristico;
import model.Tour;
import service.TourService;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        GestorDatos gestorDatos = new GestorDatos();
        TourService tourService = new TourService();

        ArrayList<Tour> tours = gestorDatos.cargarToursDesdeCSV("src/tours.csv");

        OperadorTuristico operador = new OperadorTuristico("Llanquihue Tour");

        for (Tour tour : tours) {
            operador.agregarTour(tour);
        }

        System.out.println("===== SISTEMA LLANQUIHUE TOUR =====");
        System.out.println(operador);
        System.out.println();

        tourService.mostrarTours(tours);

        System.out.println();

        tourService.buscarPorTipo(tours, "Lacustre");

        System.out.println();

        tourService.buscarPorNombre(tours, "Cultural");
    }
}