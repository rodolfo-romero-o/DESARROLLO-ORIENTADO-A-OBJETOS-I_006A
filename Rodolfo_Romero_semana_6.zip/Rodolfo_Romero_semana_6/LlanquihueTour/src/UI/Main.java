package ui;

import data.GestorServicios;
import model.ServicioTuristico;

public class Main {

    public static void main(String[] args) {

        GestorServicios gestorServicios = new GestorServicios();
        ServicioTuristico[] servicios = gestorServicios.crearServiciosDePrueba();

        System.out.println("===== LLANQUIHUE TOUR =====");
        System.out.println("Servicios turísticos disponibles");
        System.out.println();

        for (ServicioTuristico servicio : servicios) {
            System.out.println(servicio.toString());
        }
    }
}
