package model;

public class Tour {

    private String nombre;
    private String tipo;
    private int precio;
    private GuiaTuristico guia;

    public Tour(String nombre, String tipo, int precio, GuiaTuristico guia) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.precio = precio;
        this.guia = guia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        try {
            if (precio <= 0) {
                throw new Exception("El precio debe ser mayor a 0");
            }
            this.precio = precio;
        } catch (Exception e) {
            System.out.println("Error en tour: " + e.getMessage());
        }
    }

    public GuiaTuristico getGuia() {
        return guia;
    }

    public void setGuia(GuiaTuristico guia) {
        this.guia = guia;
    }

    @Override
    public String toString() {
        return "Tour: " + nombre +
                " | Tipo: " + tipo +
                " | Precio: $" + precio +
                " | Guía: " + guia.getNombre();
    }
}