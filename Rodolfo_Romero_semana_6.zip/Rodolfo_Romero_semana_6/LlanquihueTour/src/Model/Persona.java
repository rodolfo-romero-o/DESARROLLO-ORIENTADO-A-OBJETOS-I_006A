package model;

public class Persona {

    private String nombre;
    private String rut;
    private String telefono;
    private Direccion direccion;

    public Persona(String nombre, String rut, String telefono, Direccion direccion) {
        this.nombre = nombre;
        this.rut = rut;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        try {
            if (nombre == null || nombre.trim().isEmpty()) {
                throw new Exception("El nombre no puede estar vacío");
            }
            this.nombre = nombre;
        } catch (Exception e) {
            System.out.println("Error en persona: " + e.getMessage());
        }
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre +
                " | RUT: " + rut +
                " | Teléfono: " + telefono +
                " | Dirección: " + direccion;
    }
}