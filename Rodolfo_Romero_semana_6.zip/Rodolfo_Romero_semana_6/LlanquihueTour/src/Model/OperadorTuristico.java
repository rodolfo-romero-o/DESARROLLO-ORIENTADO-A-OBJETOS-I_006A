package model;

import java.util.ArrayList;

public class OperadorTuristico {

    private String nombre;
    private ArrayList<Tour> tours;

    public OperadorTuristico(String nombre) {
        this.nombre = nombre;
        this.tours = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public ArrayList<Tour> getTours() {
        return tours;
    }

    public void agregarTour(Tour tour) {
        tours.add(tour);
    }

    @Override
    public String toString() {
        return "Operador turístico: " + nombre +
                " | Cantidad de tours: " + tours.size();
    }
}