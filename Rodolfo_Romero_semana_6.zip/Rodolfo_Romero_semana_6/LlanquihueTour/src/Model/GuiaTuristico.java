package model;

public class GuiaTuristico extends Empleado {

    private String idioma;
    private int experiencia;

    public GuiaTuristico(String nombre, String rut, String telefono, Direccion direccion,
                         String cargo, int sueldo, String idioma, int experiencia) {
        super(nombre, rut, telefono, direccion, cargo, sueldo);
        this.idioma = idioma;
        this.experiencia = experiencia;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public int getExperiencia() {
        return experiencia;
    }

    public void setExperiencia(int experiencia) {
        try {
            if (experiencia < 0) {
                throw new Exception("La experiencia no puede ser negativa");
            }
            this.experiencia = experiencia;
        } catch (Exception e) {
            System.out.println("Error en guía turístico: " + e.getMessage());
        }
    }

    @Override
    public String toString() {
        return super.toString() +
                " | Idioma: " + idioma +
                " | Experiencia: " + experiencia + " años";
    }
}