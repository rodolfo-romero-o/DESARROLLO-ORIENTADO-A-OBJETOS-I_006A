package model;

public class Empleado extends Persona {

    private String cargo;
    private int sueldo;

    public Empleado(String nombre, String rut, String telefono, Direccion direccion, String cargo, int sueldo) {
        super(nombre, rut, telefono, direccion);
        this.cargo = cargo;
        this.sueldo = sueldo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        try {
            if (sueldo <= 0) {
                throw new Exception("El sueldo debe ser mayor a 0");
            }
            this.sueldo = sueldo;
        } catch (Exception e) {
            System.out.println("Error en empleado: " + e.getMessage());
        }
    }

    @Override
    public String toString() {
        return super.toString() +
                " | Cargo: " + cargo +
                " | Sueldo: $" + sueldo;
    }
}