package model;

public class Direccion {

    private String ciudad;
    private String calle;
    private int numero;

    public Direccion(String ciudad, String calle, int numero) {
        this.ciudad = ciudad;
        this.calle = calle;
        this.numero = numero;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        try {
            if (numero <= 0) {
                throw new Exception("El número debe ser mayor a 0");
            }
            this.numero = numero;
        } catch (Exception e) {
            System.out.println("Error en dirección: " + e.getMessage());
        }
    }

    @Override
    public String toString() {
        return calle + " #" + numero + ", " + ciudad;
    }
}