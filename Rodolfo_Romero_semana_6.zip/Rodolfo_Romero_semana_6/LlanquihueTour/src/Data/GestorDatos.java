package data;

import model.Direccion;
import model.GuiaTuristico;
import model.Tour;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class GestorDatos {

    public ArrayList<Tour> cargarToursDesdeCSV(String rutaArchivo) {

        ArrayList<Tour> tours = new ArrayList<>();

        try {
            BufferedReader lector = new BufferedReader(new FileReader(rutaArchivo));
            String linea;

            while ((linea = lector.readLine()) != null) {

                String[] datos = linea.split(";");

                if (datos.length == 3) {
                    String nombreTour = datos[0];
                    String tipo = datos[1];
                    int precio = Integer.parseInt(datos[2]);

                    Direccion direccionGuia = new Direccion("Puerto Varas", "Centro", 100);

                    GuiaTuristico guia = new GuiaTuristico(
                            "Guía Llanquihue",
                            "11.111.111-1",
                            "987654321",
                            direccionGuia,
                            "Guía turístico",
                            650000,
                            "Español",
                            3
                    );

                    Tour tour = new Tour(nombreTour, tipo, precio, guia);
                    tours.add(tour);
                }
            }

            lector.close();

        } catch (Exception e) {
            System.out.println("Error al cargar archivo: " + e.getMessage());
        }

        return tours;
    }
}