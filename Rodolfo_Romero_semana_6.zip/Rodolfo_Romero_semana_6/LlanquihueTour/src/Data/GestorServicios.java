package data;

import model.ExcursionCultural;
import model.PaseoLacustre;
import model.RutaGastronomica;
import model.ServicioTuristico;

public class GestorServicios {

    public ServicioTuristico[] crearServiciosDePrueba() {

        ServicioTuristico[] servicios = new ServicioTuristico[6];

        servicios[0] = new RutaGastronomica("Sabores de Puerto Varas", 3, 4);
        servicios[1] = new RutaGastronomica("Ruta del Kuchen y Café", 2, 3);

        servicios[2] = new PaseoLacustre("Navegación por el Lago Llanquihue", 4, "Catamarán");
        servicios[3] = new PaseoLacustre("Paseo al Atardecer", 2, "Lancha turística");

        servicios[4] = new ExcursionCultural("Historia de Frutillar", 3, "Teatro del Lago");
        servicios[5] = new ExcursionCultural("Patrimonio de Puerto Octay", 4, "Casa Niklitschek");

        return servicios;
    }
}
