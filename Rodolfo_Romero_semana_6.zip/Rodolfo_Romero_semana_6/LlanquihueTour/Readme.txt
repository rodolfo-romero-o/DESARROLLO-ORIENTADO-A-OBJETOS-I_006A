# LlanquihueTour


o Breve descripción
o Estructura de carpetas
o Instrucciones para ejecutar la clase Main


## Descripción

LlanquihueTourApp es una aplicación desarrollada en Java para la gestión básica de una agencia de turismo.


## Estructura del proyecto


LlanquihueTourApp/
│
├── src/
│   ├── model/
│   │   ├── Direccion.java
│   │   ├── Persona.java
│   │   ├── Empleado.java
│   │   └── Tour.java
│   │
│   ├── data/
│   │   └── GestorDatos.java
│   │
│   └── ui/
│       └── Main.java
│
├── resources/
│   └── tours.txt
│
└── README.md
-------------------------------------V2
src
│
├── app
│   └── Main.java
│
├── model
│   ├── Persona.java
│   ├── Empleado.java
│   ├── GuiaTuristico.java
│   ├── Direccion.java
│   ├── Tour.java
│
├── service
│   └── TourService.java
│
├── data
│   └── GestorDatos.java
│
└── resources
    └── tours.csv


## Uso 

precionar el boton play
